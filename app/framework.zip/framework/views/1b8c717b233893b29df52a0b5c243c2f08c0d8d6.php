<div id="bookDeliveryDiv" style="width: 100%; display:flex; justify-content: flex-end; flex-direction: row;">
    <div style="flex-direction: column; display:flex; text-align: center; align-items: center;">
        <form action="<?php echo e(route('logout')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <i class="fa-solid fa-user fa-4x" style="color: #1999D0; text-align: center; margin-bottom: 5px"></i>
            <p>Welcome <?php echo e(auth()->user()->firstname); ?> <?php echo e(auth()->user()->lastname); ?> <br>
                <button type="submit"> Logout</button>
            </p>
        </form>
    </div>
</div><?php /**PATH /Users/test/Documents/Laravel/food-app/resources/views/_partials/logout.blade.php ENDPATH**/ ?>