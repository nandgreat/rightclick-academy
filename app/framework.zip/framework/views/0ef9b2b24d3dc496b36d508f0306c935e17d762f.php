<!DOCTYPE html>
<html>

<head>
    <?php echo $__env->make('layouts.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="row bg-blue-color justify-content-center" style="min-height: 100vh;">
        <?php if(session()->get('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH /Users/test/Documents/Laravel/food-app/resources/views/layouts/blue-color.blade.php ENDPATH**/ ?>