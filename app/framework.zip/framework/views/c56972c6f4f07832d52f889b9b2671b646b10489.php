<?php $__env->startSection('content'); ?>
    <div class="row">
        
        <img style="width: 100%; height: 500px" src="<?php echo e(asset('images/ordaar_login_bg.png')); ?>" alt="">
        
    </div>
    <a class="row d-flex justify-content-center" href="<?php echo e(route('order-type', ['type' => 'delivery'])); ?>"
        style="cursor: pointer">
        <div class="col-md-12 col-sm-12 d-flex justify-content-center" style="margin-top: 15%">
            <img src="<?php echo e(asset('images/delivery.svg')); ?>" alt="Vector1989" class="vector-vector" />
        </div>
        <div class="col-md-12 col-sm-12 d-flex justify-content-center delivery-text font-weight-bolder">Swift delivery</div>
    </a>
    <a class="row d-flex justify-content-center" href="<?php echo e(route('order-type', ['type' => 'checkin'])); ?>"
        style="cursor: pointer">
        <div class="col-md-12 col-sm-12 d-flex justify-content-center" style="margin-top: 15%">
            <img src="<?php echo e(asset('images/swift.svg')); ?>" alt="Vector1989" class="vector-vector" />
        </div>
        <div class="col-md-12 col-sm-12 delivery-text">Fresh and Sweet</div>
    </a>
    <div class="row d-flex justify-content-center my-5" style="height: fit-content">
        <div class="d-flex justify-content-center">
            <a href="<?php echo e(route('login')); ?>" class="btn"
                style="background-color:#1a9ad1;color:white; diplay:flex; text-align:center;">
                Continue
            </a>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.white', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/test/Documents/Laravel/food-app/resources/views/continue.blade.php ENDPATH**/ ?>